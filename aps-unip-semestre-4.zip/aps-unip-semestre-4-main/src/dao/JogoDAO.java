package dao;

import model.Jogo;

public interface JogoDAO extends DAO<Jogo>{
	
}
