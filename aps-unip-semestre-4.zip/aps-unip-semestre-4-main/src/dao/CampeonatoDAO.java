package dao;

import model.Campeonato;

public interface CampeonatoDAO extends DAO<Campeonato>{

}
