package view;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.SwingConstants;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Campeonatos extends JFrame {

    public Campeonatos() {
        setTitle("Campeonatos");
        setSize(518, 664);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false); 
        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(400, 300));

        ImageIcon icon = new ImageIcon("src\\img\\CampoFutebol.png");
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
        layeredPane.add(imageLabel, Integer.valueOf(0));

        JLabel tituloLabel = new JLabel("Escolha o Campeonato", SwingConstants.CENTER);
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 32));
        tituloLabel.setForeground(Color.WHITE); 
        tituloLabel.setBounds(0, 20, getWidth(), 50); 
        layeredPane.add(tituloLabel, Integer.valueOf(1));
        
        	JLabel textoClicavel3 = new JLabel("Campeonato A");
        	textoClicavel3.setFont(new Font("Arial", Font.PLAIN, 20));
        	textoClicavel3.setForeground(Color.BLUE); 
       		textoClicavel3.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
       		textoClicavel3.setBounds(170, 350, 170, 30); 
        		layeredPane.add(textoClicavel3, Integer.valueOf(1));
        
        	JLabel textoClicavel2 = new JLabel("Brasileirão Série B");
        	textoClicavel2.setFont(new Font("Arial", Font.PLAIN, 20));
        	textoClicavel2.setForeground(Color.BLUE); 
        	textoClicavel2.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
        	textoClicavel2.setBounds(170, 250, 170, 30); 
        	layeredPane.add(textoClicavel2, Integer.valueOf(1));

        	JLabel textoClicavel = new JLabel("Brasileirão Série A");
        	textoClicavel.setFont(new Font("Arial", Font.PLAIN, 20));
        	textoClicavel.setForeground(Color.BLUE); 
        	textoClicavel.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
        	textoClicavel.setBounds(170, 150, 170, 30); 
        	layeredPane.add(textoClicavel, Integer.valueOf(1));

        textoClicavel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                CampeonatoView campeonatoView = new CampeonatoView("Informações do Campeonato");
                campeonatoView.setVisible(true);

                dispose();
            }
        });

        add(layeredPane);
    }

    public static void main(String[] args) {
        Campeonatos tela = new Campeonatos();
        tela.setVisible(true);
    }
}